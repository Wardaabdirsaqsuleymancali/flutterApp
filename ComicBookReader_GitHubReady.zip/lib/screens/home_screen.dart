
import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Comic Library')),
      body: Center(child: Text('Welcome to the Comic Library!')),
    );
  }
}
